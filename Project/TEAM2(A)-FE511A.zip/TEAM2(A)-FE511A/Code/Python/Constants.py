import Util as util

global HistoricalDataSet

HistoricalDataSet={
	'blk':util.getAbsFileName('blk-historical-data-table.csv'),
	'snp500':util.getAbsFileName('s&p500-historical-data-table.csv')
	}