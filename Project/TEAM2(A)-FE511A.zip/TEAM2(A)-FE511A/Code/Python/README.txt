README.txt

To run the script, open all the files in Spyder IDE and run the Main.py script.
Once the script is executed successfully, you can see the graph generated. This is the graph of implementing Backtesing Trading Strategy - EMA on S&P 500 Index.